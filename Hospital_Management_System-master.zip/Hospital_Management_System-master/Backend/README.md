<h1>This is the backend made for the Hospital Management App.</h1> 

<h2>Deployed on: <a href="https://zany-gray-clam-gear.cyclic.app/">Cyclic</a></h2>
